def say_hello2(name: str) -> str:
    return f"Hello, {name}! from another core file"