from .core import say_hello
from .core2 import say_hello2