# pypi_test

This is a normal test scripts to test the PyPi.

## Installation

```bash
pip install kamalfirstpackage
